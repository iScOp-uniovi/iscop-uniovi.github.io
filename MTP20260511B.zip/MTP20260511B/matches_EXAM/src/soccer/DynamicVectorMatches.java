/*
 * Programming Methodology Practice.
 *
 * @author Programming Methodology Professors
 */
package soccer;

/**
 * Class that allows to represent dynamic vectors of Match.
 *
 * @author Programming Methodology Professors
 */
public class DynamicVectorMatches extends DynamicVectorObjects {

	public DynamicVectorMatches() {

	}

	public DynamicVectorMatches(DynamicVectorMatches vDM) {
		super(vDM);
	}

	public DynamicVectorMatches(int size) {
		super(size);
	}

	public DynamicVectorMatches(Match[] v) {
		super((Object[]) v);
	}

	@Override
	public Match get(int i) {
		return (Match) super.get(i);
	}

	// Other methods
	@Override
	public Match[] vectorNormal() { // returns a Match[] as the matches of this vector
		Match[] temp = new Match[this.length()];
		for (int i = 0; i < temp.length; i++)
			temp[i] = this.get(i);
		return temp;
	}

}
