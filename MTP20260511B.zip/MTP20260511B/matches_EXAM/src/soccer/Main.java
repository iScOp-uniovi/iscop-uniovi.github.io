package soccer;

public class Main {

	public static void main(String[] args) {
		String inputTxt = "partidos_Asturias2007.csv";
		String outputTxt = "filtered_matches.txt";
		String outputBin = "matches.ser";

		DynamicVectorMatches v = null;
		v = loadMatches(inputTxt);
		showMatches(v);
		System.out.println("==============================\n");

		String campo = "golesLocal";
		int minimo = 5;

		writeFilteredBy(v, outputTxt, campo, minimo);

		serialize(v, outputBin);
		v = deserialize(outputBin);
		System.out.println("Deserialized matches:");
		showMatches(v);
	}

	private static DynamicVectorMatches loadMatches(String fileName) {
		// TODO
		return null;
	}

	private static void showMatches(DynamicVectorMatches v) {
		// TODO
	}

	private static void writeFilteredBy(DynamicVectorMatches v, String fileName, String campo, int minimo) {
		// TODO
	}

	private static void serialize(DynamicVectorMatches v, String fileName) {
		// TODO
	}

	private static DynamicVectorMatches deserialize(String salidaBin) {
		// TODO
		return null;
	}

}
