set cuenta=programacion
set workspace=MTP20260511B


@echo lanzando eclipse...
@start C:\eclipse\eclipse.exe -data c:\users\%cuenta%\desktop\%workspace%

exit