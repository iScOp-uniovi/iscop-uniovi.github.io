package beaches;

public class Main {

	public static void main(String[] args) {
		String filename = "playas.csv";
		DynamicVectorBeaches dVBWest;

		dVBWest = createVectorBeaches(filename, "Occidente de Asturias");
		System.out.printf("Total beaches in the west of Asturias: %d\n", dVBWest.length());

		writeFileTypeBeaches(dVBWest, "beachesSandWest.txt", "arena");
		System.out.println("Generated txt file");

		serialize(dVBWest, "beaches.ser");
		System.out.println("Serialization done: stored vector with " + dVBWest.length() + " beaches");
		DynamicVectorBeaches dVBWest2 = deserialize("beaches.ser");
		System.out.println("Deserialization done: read vector  with " + dVBWest2.length() + " beaches");

	}

	public static DynamicVectorBeaches createVectorBeaches(String filename, String targetZone) {
		// TODO
		return null;
	}

	public static void writeFileTypeBeaches(DynamicVectorBeaches dvb, String filename, String type) {
		// TODO
	}

	private static void serialize(DynamicVectorBeaches dvb, String outputFileName) {
		// TODO
	}

	private static DynamicVectorBeaches deserialize(String inputFileName) {
		// TODO
		return null;
	}

}
