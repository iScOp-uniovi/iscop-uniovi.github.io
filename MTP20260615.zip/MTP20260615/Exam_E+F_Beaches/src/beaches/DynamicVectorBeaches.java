package beaches;

/**
 * Class that allows to represent dynamic vectors of FuelStation
 *
 * @author Programming Methodology Professors
 */
public class DynamicVectorBeaches extends DynamicVectorObjects {
	
	public DynamicVectorBeaches() {

	}

	public DynamicVectorBeaches(DynamicVectorBeaches vDE) {
		super(vDE);
	}

	public DynamicVectorBeaches(int size) {
		super(size);
	}

	public DynamicVectorBeaches(Beach[] v) {
		super((Object[]) v);
	}

	@Override
	public Beach get(int i) {
		return (Beach) super.get(i);
	}

	// Other methods
	@Override
	public Beach[] vectorNormal() { // returns a FuelStation[] as the integers of vOI
		Beach[] temp = new Beach[this.length()];
		for (int i = 0; i < temp.length; i++)
			temp[i] = this.get(i);
		return temp;
	}

}
