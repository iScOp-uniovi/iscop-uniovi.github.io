package beaches;


public class Beach {

	// TODO Complete
}
