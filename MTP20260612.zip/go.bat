set cuenta=programacion
set workspace=MTP20260612


@echo lanzando eclipse...
@start C:\eclipse\eclipse.exe -data c:\users\%cuenta%\desktop\%workspace%