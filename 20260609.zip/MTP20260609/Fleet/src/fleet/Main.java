package fleet;

public class Main {
	public static void main(String[] args) {
		// Create a static array of assets of each type.
		/* TODO: REPLACE Object with a specific class */ Object[] assets = {/* TODO: populate fleet assets */};

		System.out.println("=== a) Electric van with the largest volume ===");
		showLargestElectricVan(assets);

		System.out.println("\n=== b) Total revenue (minimum 6 dispatches) ===");
		double total = computeTotalRevenue(assets, 6);
		System.out.println("Total revenue: " + total);

		System.out.println("\n=== c) Summary and manifest ===");
		showSummaryAndManifest(assets);

		System.out.println("\n=== d) Sorted fleet (logistics centers first) ===");
		sortFleetAssets(assets);
		for (/* TODO: REPLACE Object with a specific class */ Object asset : assets) {
			System.out.println(asset);
		}
	}

	// a. Display the license plate and volume of the electric van (ECO) with the largest volume.
	private static void showLargestElectricVan(/* TODO: REPLACE Object with a specific class */ Object[] vA) {
		// TODO: find and print the electric van with the largest volume
	}

	// b. Return the total revenue of assets with at least minDispatches dispatches.
	private static double computeTotalRevenue(/* TODO: REPLACE Object with a specific class */ Object[] vA, int minDispatches) {
		// TODO: compute and return total revenue
		return 0.0;
	}

	// c. Display the summary of each asset and, if it is a logistics center, its assigned vehicles.
	private static void showSummaryAndManifest(/* TODO: REPLACE Object with a specific class */ Object[] vA) {
		// TODO: print the summary of each asset and the manifest of each logistics center
	}

	// d. Sort the array in-place: logistics centers first, then the rest.
	private static void sortFleetAssets(/* TODO: REPLACE Object with a specific class */ Object[] vA) {
		// TODO: implement sorting/partitioning so that logistics centers appear first
	}
}
