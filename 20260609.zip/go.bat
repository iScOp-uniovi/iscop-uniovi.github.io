set cuenta=programacion
set workspace=MTP20260609


@echo lanzando eclipse...
@start C:\eclipse\eclipse.exe -data c:\users\%cuenta%\desktop\%workspace%

@echo lanzando gaphor...
"C:\Program Files\Gaphor\gaphor.exe" C:\Users\%cuenta%\Desktop\MTP20260505\Construction\resources.gaphor
exit