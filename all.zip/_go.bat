set cuenta=programacion
set enunciado=MTP20260615.zip
set workspace=MTP20260615
set urlbase=https://github.com/iScOp-uniovi/iscop-uniovi.github.io/raw/main/

@echo Cambiando el tiempo de bloqueo de sesión a 90 minutos
powercfg /change monitor-timeout-ac 90
powercfg /change standby-timeout-ac 90

@echo Borrando Papelera
./downloads/recycle /E:C


@echo Borrando Descargas
rem @for /D %%p in (c:\users\%cuenta%\downloads\*.*)  do rd /S /Q "%%p"
rem @del /F /S /Q c:\users\%cuenta%\downloads\*.*

@echo BACKUP escritorio previo comprimido con password
@"C:\Program Files\7-Zip\7z.exe" a -mx=0 -p{JUNIO.MTP26} c:\users\%cuenta%\downloads\MTP20260615 c:\users\%cuenta%\desktop\*.* c:\users\%cuenta%\desktop\*

@echo Borrando Escritorio
@for /D %%p in (c:\users\%cuenta%\desktop\*.*)  do rd /S /Q "%%p"
@del /F /S /Q c:\users\%cuenta%\desktop\*.*

@echo Borrando Documents
@for /D %%p in (c:\users\%cuenta%\documents\*.*)  do rd /S /Q "%%p"
@del /F /S /Q c:\users\%cuenta%\documents\*.*


@echo descargando contenidos
rem echo curl -L -o c:\users\%cuenta%\desktop\%enunciado% %urlbase%/%enunciado%
rem @curl -L -o c:\users\%cuenta%\desktop\%enunciado% %urlbase%/%enunciado%

echo copiando lo que sea
rem @xcopy %enunciado% c:\users\%cuenta%\desktop\
rem @xcopy go.bat c:\users\%cuenta%\desktop\

echo descomprimiendo...
@"C:\Program Files\7-Zip\7z.exe" x c:\users\%cuenta%\downloads\%enunciado% -oc:\users\%cuenta%\desktop
@del /F /S /Q c:\users\%cuenta%\downloads\%enunciado%

echo lanzando eclipse...
start C:\eclipse\eclipse.exe -data c:\users\%cuenta%\desktop\%workspace%

@echo lanzando gaphor...
rem @start "" "C:\Program Files\Gaphor\gaphor.exe" C:\Users\%cuenta%\Desktop\MTP20260505\Construction\resources.gaphor
