set cuenta=programacion
set workspace=MTP20260505


@echo lanzando eclipse...
@start C:\eclipse\eclipse.exe -data c:\users\%cuenta%\desktop\%workspace%

@echo lanzando gaphor...
"C:\Program Files\Gaphor\gaphor.exe" C:\Users\%cuenta%\Desktop\MTP20260505\Construction_Solution_EN\resources.gaphor
exit