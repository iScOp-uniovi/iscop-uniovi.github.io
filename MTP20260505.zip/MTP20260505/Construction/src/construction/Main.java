package construction;

public class Main {
	public static void main(String[] args) {
		/* TODO: REPLACE Object with a specific class */ Object[] resources = {/* TODO: populate resources */};

		System.out.println("\nTotal cost: " + computeTotalCost(resources));

		System.out.println("\nCertified resources:");
		showCertifiedResources(resources);

		System.out.println("\nOperator with the highest hazard pay bonus:");
		showHighestHazardBonus(resources);

		System.out.println("\nSorting resources (certified resources first)...");
		sortResources(resources);

		// Show sorted resources.
		for (/* TODO: REPLACE Object with a specific class */ Object resource : resources) {
			System.out.println(resource);
		}
	}

	private static void sortResources(/* TODO: REPLACE Object with a specific class */ Object[] resources) {
		// TODO: implement sorting (certified first)
	}

	private static void showHighestHazardBonus(/* TODO: REPLACE Object with a specific class */ Object[] resources) {
		// TODO: find and print the operator with the highest hazard pay bonus
	}

	private static void showCertifiedResources(/* TODO: REPLACE Object with a specific class */ Object[] resources) {
		// TODO: iterate resources and print certified ones with their body and date
	}

	private static double computeTotalCost(/* TODO: REPLACE Object with a specific class */ Object[] resources) {
		// TODO: compute and return total cost
		return 0.0;
	}
}